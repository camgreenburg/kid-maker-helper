import { Play } from "lucide-react";

interface VideoPlayerProps {
  videoId: string;
  autoplay?: boolean;
}

export function VideoPlayer({ videoId, autoplay = false }: VideoPlayerProps) {
  const src = `https://www.youtube.com/embed/${videoId}?rel=0&autoplay=${autoplay ? 1 : 0}`;

  return (
    <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-black shadow-lg ring-4 ring-black/5">
      <iframe
        className="absolute inset-0 w-full h-full"
        src={src}
        title="Video player"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    </div>
  );
}

interface VideoCardProps {
  videoId: string;
  title: string;
  onOpen: () => void;
}

export function VideoCard({ videoId, title, onOpen }: VideoCardProps) {
  const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

  return (
    <div className="group relative w-full max-w-sm rounded-xl overflow-hidden bg-card border shadow-sm hover:shadow-md transition-all duration-300">
      {/* Thumbnail Container */}
      <div className="relative aspect-video bg-muted">
        <img 
          src={thumbnailUrl} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
        
        {/* Play Button Overlay */}
        <button
          onClick={onOpen}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div className="w-12 h-12 rounded-full bg-white/90 shadow-lg flex items-center justify-center text-primary group-hover:scale-110 group-hover:bg-white transition-all duration-300">
            <Play className="w-5 h-5 fill-current ml-0.5" />
          </div>
        </button>
      </div>

      {/* Content */}
      <div className="p-3">
        <h4 className="font-display font-semibold text-sm line-clamp-2 leading-tight">
          {title}
        </h4>
        <button 
          onClick={onOpen}
          className="mt-2 text-xs font-medium text-primary hover:underline flex items-center gap-1"
        >
          Open video
        </button>
      </div>
    </div>
  );
}

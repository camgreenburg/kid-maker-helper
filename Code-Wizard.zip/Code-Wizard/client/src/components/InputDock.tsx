import { useState, useRef, ChangeEvent } from "react";
import { Send, Camera, X, Loader2, Image as ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface InputDockProps {
  onSend: (text: string, image?: string) => void;
  isLoading?: boolean;
}

export function InputDock({ onSend, isLoading }: InputDockProps) {
  const [text, setText] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = () => {
    if ((!text.trim() && !imagePreview) || isLoading) return;
    
    // Pass undefined if empty string/null to match API
    onSend(text.trim() || undefined as any, imagePreview || undefined);
    
    setText("");
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-lg border-t border-border p-4 pb-6 md:pb-4 shadow-[0_-4px_20px_-4px_rgba(0,0,0,0.05)]">
      <div className="max-w-3xl mx-auto space-y-3">
        
        {/* Image Preview */}
        {imagePreview && (
          <div className="relative inline-block group">
            <img 
              src={imagePreview} 
              alt="Preview" 
              className="h-24 w-auto rounded-lg border shadow-sm object-cover"
            />
            <button
              onClick={() => {
                setImagePreview(null);
                if (fileInputRef.current) fileInputRef.current.value = "";
              }}
              className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 shadow-md hover:scale-110 transition-transform"
            >
              <X size={14} />
            </button>
          </div>
        )}

        <div className="flex gap-3 items-end">
          {/* File Input */}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            ref={fileInputRef}
            onChange={handleFileSelect}
          />
          
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex-shrink-0 w-11 h-11 rounded-full bg-secondary/10 hover:bg-secondary/20 text-secondary-foreground border border-transparent hover:border-secondary/20 flex items-center justify-center transition-all duration-200 active:scale-95"
            title="Upload image"
          >
            <Camera size={22} className="text-orange-600" />
          </button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="What do you want to build?"
              className="w-full resize-none rounded-2xl border-border bg-white pl-4 pr-12 py-3 text-[15px] focus:ring-2 focus:ring-primary/20 focus:border-primary min-h-[48px] max-h-[120px] shadow-sm transition-all"
              rows={1}
              style={{ minHeight: "48px" }}
            />
          </div>

          {/* Send Button */}
          <button
            onClick={handleSend}
            disabled={(!text.trim() && !imagePreview) || isLoading}
            className={cn(
              "flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all duration-200",
              (!text.trim() && !imagePreview) || isLoading
                ? "bg-muted text-muted-foreground cursor-not-allowed"
                : "bg-primary text-primary-foreground hover:scale-105 hover:shadow-xl hover:shadow-primary/25 active:scale-95"
            )}
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} className="ml-0.5" />}
          </button>
        </div>
        
        <div className="text-center">
          <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">
            Powered by AI • Safe for Kids
          </p>
        </div>
      </div>
    </div>
  );
}

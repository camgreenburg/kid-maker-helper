import { cn } from "@/lib/utils";
import { type Chat, type ChatMetadata } from "@shared/schema";
import { VideoCard } from "./VideoPlayer";
import { motion } from "framer-motion";
import { Bot, User } from "lucide-react";

interface ChatMessageProps {
  message: Chat;
  onOpenVideo?: (videoId: string, title: string) => void;
  onChoiceSelect?: (choice: string) => void;
}

export function ChatMessage({ message, onOpenVideo, onChoiceSelect }: ChatMessageProps) {
  const isUser = message.role === 'user';
  const metadata = message.metadata as ChatMetadata | null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex gap-3 w-full max-w-3xl mx-auto mb-6",
        isUser ? "flex-row-reverse" : "flex-row"
      )}
    >
      {/* Avatar */}
      <div className={cn(
        "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center shadow-sm",
        isUser ? "bg-blue-100 text-blue-600" : "bg-orange-100 text-orange-600"
      )}>
        {isUser ? <User size={16} /> : <Bot size={16} />}
      </div>

      <div className={cn("flex flex-col gap-2 max-w-[85%]", isUser ? "items-end" : "items-start")}>
        {/* Bubble */}
        {(message.content || message.imageUrl) && (
          <div className={cn(
            "rounded-2xl px-4 py-3 shadow-sm text-[15px] leading-relaxed",
            isUser 
              ? "bg-primary text-primary-foreground rounded-tr-sm" 
              : "bg-white border border-border text-foreground rounded-tl-sm"
          )}>
            {message.imageUrl && (
              <img 
                src={message.imageUrl} 
                alt="User upload" 
                className="max-w-full rounded-lg mb-2 border border-black/10"
              />
            )}
            {message.content && <p className="whitespace-pre-wrap">{message.content}</p>}
          </div>
        )}

        {/* Video Attachment */}
        {!isUser && metadata?.video && onOpenVideo && (
          <div className="mt-1 w-full">
            <VideoCard 
              videoId={metadata.video.videoId}
              title={metadata.video.title}
              onOpen={() => onOpenVideo(metadata.video!.videoId, metadata.video!.title)}
            />
          </div>
        )}

        {/* Choices / Clarification */}
        {!isUser && metadata?.choices && onChoiceSelect && (
          <div className="flex flex-wrap gap-2 mt-2">
            {metadata.choices.map((choice, i) => (
              <button
                key={i}
                onClick={() => onChoiceSelect(choice)}
                className="px-4 py-2 bg-white border border-primary/20 hover:border-primary text-primary text-sm font-medium rounded-full shadow-sm hover:shadow-md hover:bg-blue-50 transition-all active:scale-95"
              >
                {choice}
              </button>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}

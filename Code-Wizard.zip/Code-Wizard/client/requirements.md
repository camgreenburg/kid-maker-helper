## Packages
framer-motion | For smooth layout transitions and playful interactions
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
- Session ID needs to be generated on client-side on first load if not present.
- YouTube embedding requires parsing video IDs.
- Images from input dock need to be converted to base64 before sending to API.
- The UI mimics a mobile-first "dock" layout but works responsively on desktop.
